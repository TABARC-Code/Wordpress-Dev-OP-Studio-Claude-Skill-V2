# Accessibility Reference

Author: TABARC-Code / Blackwood Studio
Load this for WCAG compliance, WordPress accessibility coding standards,
ARIA, keyboard navigation, and accessible block development.

---

## WCAG 2.1 — Minimum Targets for WordPress Projects

WordPress accessibility standard targets WCAG 2.1 Level AA. This is the baseline
expected in professional work and required for public sector sites in the UK (PSBAR).

**Four principles — every element must be:**

| Principle | Meaning | Failing example |
|---|---|---|
| Perceivable | Users can perceive all content | Image with no alt text |
| Operable | Users can operate all controls | Button only activatable by click, not keyboard |
| Understandable | Users can understand content and controls | Form field with no label |
| Robust | Content works with assistive technologies | Custom widget with no ARIA roles |

---

## WordPress Accessibility Coding Standards

WordPress has its own accessibility coding standards on top of WCAG:
https://developer.wordpress.org/coding-standards/wordpress-coding-standards/accessibility/

Key rules:

- Every `<img>` must have an `alt` attribute. Decorative images: `alt=""`.
- Every form field must have a `<label>` with a `for` attribute matching the input `id`.
- Interactive elements must be keyboard accessible and focusable.
- Colour alone must never convey information.
- Focus must never be removed from interactive elements.
- Error messages must be programmatically associated with their field.

---

## Semantic HTML

Semantic HTML is the foundation of accessibility. Correct element choice
removes the need for extensive ARIA.

```php
<?php
// Wrong — div soup requires ARIA to be accessible
?>
<div class="button" onclick="handleClick()">Submit</div>
<div class="nav">...</div>
<div class="article">...</div>
<div class="header">...</div>

<?php // Correct — semantics built in ?>
<button type="submit" onclick="handleClick()">Submit</button>
<nav aria-label="<?php esc_attr_e( 'Primary', 'my-plugin' ); ?>">...</nav>
<article>...</article>
<header>...</header>

<?php // Heading hierarchy — never skip levels ?>
<h1>Page Title</h1>       <!-- one per page -->
  <h2>Section</h2>
    <h3>Subsection</h3>
  <h2>Next Section</h2>
```

---

## Images — Alt Text

```php
<?php
// In PHP templates — always provide alt text context
the_post_thumbnail( 'large', [
    'alt' => esc_attr( get_the_title() ),  // Contextual alt, not filename
] );

// Decorative image — empty alt, role presentation
?>
<img src="<?php echo esc_url( $decorative_url ); ?>" alt="" role="presentation">

<?php
// wp_get_attachment_image() — pass alt explicitly
echo wp_get_attachment_image( $attachment_id, 'full', false, [
    'alt' => esc_attr( $alt_text ),
] );
```

---

## Form Accessibility

```php
<?php
// Every field needs a label — never use placeholder as the only label
?>
<div class="form-field">
    <label for="my_field_<?php echo esc_attr( $field_id ); ?>">
        <?php esc_html_e( 'Field Label', 'my-plugin' ); ?>
        <?php if ( $required ) : ?>
            <span class="required" aria-hidden="true"> *</span>
            <span class="screen-reader-text"><?php esc_html_e( '(required)', 'my-plugin' ); ?></span>
        <?php endif; ?>
    </label>
    <input
        type="text"
        id="my_field_<?php echo esc_attr( $field_id ); ?>"
        name="my_field"
        value="<?php echo esc_attr( $value ); ?>"
        <?php if ( $required ) : ?>aria-required="true"<?php endif; ?>
        <?php if ( $error ) : ?>
            aria-describedby="my_field_error_<?php echo esc_attr( $field_id ); ?>"
            aria-invalid="true"
        <?php endif; ?>
    >
    <?php if ( $error ) : ?>
        <p
            id="my_field_error_<?php echo esc_attr( $field_id ); ?>"
            class="error-message"
            role="alert"
        >
            <?php echo esc_html( $error ); ?>
        </p>
    <?php endif; ?>
</div>
```

---

## Keyboard Navigation

All interactive elements must be operable by keyboard.

```php
<?php
// Custom interactive element — must have tabindex, role, and keyboard handler
?>
<div
    class="my-toggle"
    role="button"
    tabindex="0"
    aria-expanded="false"
    aria-controls="my-panel"
>
    <?php esc_html_e( 'Toggle Panel', 'my-plugin' ); ?>
</div>
<div id="my-panel" hidden>
    <!-- Panel content -->
</div>
```

```javascript
// JavaScript — handle both click and keypress (Enter and Space activate buttons)
document.querySelectorAll( '[role="button"]' ).forEach( ( el ) => {
    el.addEventListener( 'keydown', ( event ) => {
        if ( event.key === 'Enter' || event.key === ' ' ) {
            event.preventDefault();
            el.click();
        }
    } );

    el.addEventListener( 'click', () => {
        const expanded = el.getAttribute( 'aria-expanded' ) === 'true';
        el.setAttribute( 'aria-expanded', String( ! expanded ) );
        const panel = document.getElementById( el.getAttribute( 'aria-controls' ) );
        panel.hidden = expanded;
    } );
} );
```

---

## Skip Links

Every WordPress theme must include a skip link to the main content.
Required by WCAG 2.4.1 (Bypass Blocks).

```php
<?php
// In header.php — first focusable element in the page
?>
<a class="skip-link screen-reader-text" href="#main-content">
    <?php esc_html_e( 'Skip to main content', 'my-plugin' ); ?>
</a>
```

```css
/* Make visible on focus — common WordPress pattern */
.skip-link.screen-reader-text:focus {
    clip: auto;
    height: auto;
    left: 6px;
    top: 6px;
    overflow: visible;
    position: fixed;
    width: auto;
    z-index: 100000;
    background: #f1f1f1;
    border-radius: 3px;
    box-shadow: 0 0 2px 2px rgba(0,0,0,.6);
    color: #21759b;
    display: block;
    font-size: 0.875rem;
    font-weight: 700;
    line-height: normal;
    padding: 15px 23px 14px;
    text-decoration: none;
}
```

---

## ARIA — When to Use

ARIA should supplement, not replace, semantic HTML. If a semantic element exists, use it.

```
role="button"       — Only when a <button> element cannot be used
role="alert"        — Error messages and time-sensitive updates (announced immediately)
role="status"       — Non-critical status updates (polite announcement)
role="dialog"       — Modal dialogs
role="navigation"   — Only on <nav> if label needed to distinguish multiple navs
aria-label          — Provides accessible name when visible text is absent or insufficient
aria-labelledby     — Points to visible text that serves as the label
aria-describedby    — Points to additional description (e.g. field hint, error message)
aria-expanded       — State for disclosure widgets (menus, accordions)
aria-controls       — Points to the element this control expands/controls
aria-live           — Announces dynamic content updates
aria-hidden         — Hides decorative content from screen readers
```

**Never use:**
- `aria-label` to duplicate visible text that already works as a label
- `role="presentation"` on interactive elements
- `tabindex="0"` on non-interactive elements without a role and keyboard handler
- `tabindex="-1"` to remove keyboard access from anything that should be accessible

---

## Colour Contrast

WCAG 2.1 AA requirements:

- Normal text (< 18pt or < 14pt bold): minimum contrast ratio 4.5:1
- Large text (≥ 18pt or ≥ 14pt bold): minimum 3:1
- UI components and graphical elements: minimum 3:1
- Decorative elements: no requirement

Test tools: https://webaim.org/resources/contrastchecker/

In theme.json, colour palette definitions must meet these ratios. Do not define
colour combinations in theme.json that fail contrast — editors will use them.

---

## Accessible Gutenberg Blocks

Blocks have additional accessibility requirements.

```javascript
// Every interactive block must declare keyboard support
registerBlockType( 'my-plugin/my-block', {
    // ...
    supports: {
        // Declare focus management capability
        interactivity: { clientNavigation: true },
    },
} );
```

```php
<?php
// render.php — associate label with interactive element
// Block wrapper uses get_block_wrapper_attributes() which includes aria attributes
$wrapper_attributes = get_block_wrapper_attributes( [
    'role'       => 'region',
    'aria-label' => esc_attr( $attributes['label'] ?? __( 'Content block', 'my-plugin' ) ),
] );
?>
<div <?php echo $wrapper_attributes; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
```

---

## WordPress Accessibility Testing Tools

| Tool | What it tests |
|---|---|
| Axe browser extension | Automated WCAG audit on any page |
| WAVE (WebAIM) | Accessibility report with visual overlay |
| Lighthouse (Chrome DevTools) | Accessibility score plus specific failures |
| Screen reader (NVDA free, VoiceOver macOS) | Real assistive technology test |
| Keyboard-only navigation | Tab through page — every control must be reachable |
| WordPress Accessibility Checker plugin | Flags issues in the block editor |

Automated tools catch approximately 30–40% of WCAG failures. Manual testing with
a screen reader and keyboard-only navigation is required for the rest.
