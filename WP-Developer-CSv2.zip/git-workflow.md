# Git Workflow, Local Development, Deployment, and Site Migration

Author: TABARC-Code / Blackwood Studio
Load this for Git setup, local environments, staging/production workflow,
CI/CD pipelines, and moving sites between environments.

---

## What Goes in Git

WordPress projects commit custom code, not the platform.

**Commit:**
- Custom themes (`wp-content/themes/my-theme/`)
- Custom plugins (`wp-content/plugins/my-plugin/`)
- `composer.json` and `composer.lock` (not `vendor/`)
- `package.json` and `package-lock.json` (not `node_modules/`)
- Build config files (webpack, babel, `.eslintrc`)
- Theme/plugin unit tests

**Never commit:**
- `wp-config.php` — contains database credentials and auth keys
- `wp-content/uploads/` — user-uploaded media, too large, not code
- `vendor/` — regenerate with `composer install`
- `node_modules/` — regenerate with `npm install`
- `wp-content/debug.log` — log files
- The WordPress core itself (`wp-admin/`, `wp-includes/`, root PHP files)
- `.env` files if used

---

## WordPress .gitignore

```gitignore
# WordPress core
/wp-admin/
/wp-includes/
/wp-*.php
/xmlrpc.php
/index.php
/license.txt
/readme.html

# Configuration
wp-config.php
wp-config-local.php
.env
.env.*

# Uploads
/wp-content/uploads/

# Dependencies
/wp-content/plugins/*/vendor/
/wp-content/themes/*/vendor/
/wp-content/plugins/*/node_modules/
/wp-content/themes/*/node_modules/

# Build artefacts (commit dist/ or build/ if deploying static assets via Git)
# Uncomment if using a build step that produces dist/:
# !/wp-content/themes/my-theme/dist/

# Cache and logs
*.log
/wp-content/cache/
/wp-content/advanced-cache.php
/wp-content/object-cache.php
/wp-content/db.php

# OS files
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
```

---

## Branch Strategy

```
main          Production. Only receives merges from staging. Never commit directly.
staging       Mirrors production. QA and client review here before merge to main.
develop       Active development integration branch.
feature/*     Feature branches. Branch from develop, merge back to develop.
fix/*         Bug fix branches. Branch from staging or main if hotfix.
```

```bash
# Start a new feature
git checkout develop
git pull origin develop
git checkout -b feature/my-feature-name

# Finish and merge
git checkout develop
git merge --no-ff feature/my-feature-name
git push origin develop
git branch -d feature/my-feature-name
```

---

## wp-config.php — Environment Separation

Never store credentials in Git. Use environment-specific config files.

```php
<?php
// wp-config.php — committed to Git (no credentials)
// Detects environment and loads the appropriate config.

// Load environment-specific config if it exists.
if ( file_exists( dirname( __FILE__ ) . '/wp-config-local.php' ) ) {
    require_once dirname( __FILE__ ) . '/wp-config-local.php';
} elseif ( defined( 'WP_ENV' ) && file_exists( dirname( __FILE__ ) . '/wp-config-' . WP_ENV . '.php' ) ) {
    require_once dirname( __FILE__ ) . '/wp-config-' . WP_ENV . '.php';
}

// Shared settings (not environment-specific)
define( 'WP_POST_REVISIONS', 5 );
define( 'AUTOSAVE_INTERVAL', 60 );
define( 'EMPTY_TRASH_DAYS', 7 );

// ... rest of wp-config.php
```

```php
<?php
// wp-config-local.php — NOT committed to Git
define( 'DB_NAME',     'my_local_db' );
define( 'DB_USER',     'root' );
define( 'DB_PASSWORD', 'root' );
define( 'DB_HOST',     'localhost' );
define( 'WP_DEBUG',         true );
define( 'WP_DEBUG_LOG',     true );
define( 'WP_DEBUG_DISPLAY', false );  // Log to file, never display to browser
define( 'WP_HOME',    'https://my-site.local' );
define( 'WP_SITEURL', 'https://my-site.local' );
```

```php
<?php
// wp-config-production.php — NOT committed to Git (set on server)
define( 'DB_NAME',     getenv( 'DB_NAME' ) );
define( 'DB_USER',     getenv( 'DB_USER' ) );
define( 'DB_PASSWORD', getenv( 'DB_PASSWORD' ) );
define( 'DB_HOST',     getenv( 'DB_HOST' ) );
define( 'WP_DEBUG',         false );
define( 'WP_DEBUG_LOG',     false );
define( 'WP_DEBUG_DISPLAY', false );
define( 'DISALLOW_FILE_EDIT', true );   // Disable theme/plugin editor in production
define( 'DISALLOW_FILE_MODS', false );  // Set true if you manage all updates via deploy
```

---

## Local Development Environments

Recommended options (all support WordPress out of the box):

| Tool | Best For |
|---|---|
| Local (Flywheel) | Simplest setup; GUI-driven; no CLI required |
| DDEV | Docker-based; most accurate to production; team parity |
| Lando | Docker-based; flexible; good for complex multi-service setups |
| Docker Compose | Maximum control; requires most setup |
| XAMPP/WAMP | Last resort; no SSL, no WP-CLI integration, avoid for new projects |

**DDEV quick setup:**

```bash
mkdir my-site && cd my-site
ddev config --project-type=wordpress --docroot=. --create-docroot
ddev start
ddev wp core download
ddev wp config create --dbname=db --dbuser=db --dbpass=db --dbhost=db
ddev wp core install --url=https://my-site.ddev.site --title="My Site" \
  --admin_user=admin --admin_password=admin --admin_email=admin@example.com
ddev launch
```

---

## WP-CLI Essential Commands

```bash
# Core
wp core version
wp core update
wp core verify-checksums   # Detect tampered core files

# Plugins and themes
wp plugin list
wp plugin update --all
wp plugin install query-monitor --activate
wp theme list

# Database
wp db export backup-$(date +%Y%m%d).sql     # Always export before migrations
wp db import backup.sql
wp db check                                  # Check table integrity
wp db optimize

# Search-replace (for URL migration — handles serialised data)
wp search-replace 'https://old-domain.com' 'https://new-domain.com' \
  --precise --report-changed-only

# Users
wp user list
wp user create devuser dev@example.com --role=administrator

# Cache
wp cache flush
wp rewrite flush

# Cron
wp cron event list
wp cron event run --due-now
wp cron schedule list
```

---

## Deploying: Staging to Production

Standard pattern for managed hosts (Kinsta, WP Engine, Cloudways, Flywheel):

```
1. Merge tested code from develop -> staging branch
2. Push staging branch -> triggers auto-deploy to staging environment (if CI/CD)
   OR deploy manually via DeployHQ / host dashboard
3. QA on staging — functional and regression check
4. Export production database backup before deploying
5. Merge staging -> main
6. Push main -> triggers auto-deploy to production
7. Run post-deploy checks (site loads, WooCommerce checkout, forms)
```

**Never deploy directly from a local environment to production.**
Always go through staging. One URL search-replace error on a live WooCommerce
store can corrupt serialised order data.

---

## GitHub Actions — Basic WordPress Deploy

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install Composer dependencies
        run: |
          cd wp-content/plugins/my-plugin
          composer install --no-dev --optimize-autoloader

      - name: Build assets
        run: |
          cd wp-content/themes/my-theme
          npm ci
          npm run build

      - name: Run PHPCS
        run: |
          composer global require squizlabs/php_codesniffer
          composer global require wp-coding-standards/wpcs
          phpcs --standard=WordPress wp-content/plugins/my-plugin/

      - name: Deploy via SSH
        uses: appleboy/ssh-action@v1.0.3
        with:
          host:     ${{ secrets.PRODUCTION_HOST }}
          username: ${{ secrets.PRODUCTION_USER }}
          key:      ${{ secrets.PRODUCTION_SSH_KEY }}
          script: |
            cd /var/www/html
            git pull origin main
            cd wp-content/plugins/my-plugin && composer install --no-dev
            cd /var/www/html/wp-content/themes/my-theme && npm ci && npm run build
            wp cache flush
```

---

## Site Migration — Full Process

Moving a site to a new domain or host.

```bash
# Step 1: Export database on source
wp db export migration-$(date +%Y%m%d).sql

# Step 2: Transfer files (rsync preferred over FTP)
rsync -avz --exclude='wp-content/cache' \
  user@source-server:/var/www/html/ \
  user@dest-server:/var/www/html/

# Step 3: Import database on destination
wp db import migration.sql

# Step 4: Update URLs — handles serialised data correctly
wp search-replace 'https://old-domain.com' 'https://new-domain.com' \
  --precise --report-changed-only --allow-root

# Step 5: Update wp-config.php on destination with new DB credentials

# Step 6: Flush rewrite rules
wp rewrite flush

# Step 7: Verify
wp option get siteurl
wp option get home

# Step 8: Check for any remaining references
wp search-replace 'old-domain.com' 'new-domain.com' --dry-run
```

**Serialised data warning:** Never use SQL find/replace (`UPDATE wp_options SET ...`)
directly on a migrated database. WordPress stores serialised PHP arrays in the
database with byte-length prefixes. A raw string replace breaks the serialisation.
`wp search-replace` with `--precise` handles this correctly.

---

## File Permissions — Post-Deploy

Incorrect permissions are a common post-deploy security vulnerability.

```bash
# Directories: 755, Files: 644
find /var/www/html -type d -exec chmod 755 {} \;
find /var/www/html -type f -exec chmod 644 {} \;

# wp-config.php: 640 (owner read/write, group read, no world access)
chmod 640 /var/www/html/wp-config.php

# Uploads directory must be writable by web server
chmod 755 /var/www/html/wp-content/uploads

# wp-config.php must never be world-readable
# Never set 777 on any directory
```

---

## Debugging Constants

```php
// Development only — never in production
define( 'WP_DEBUG',         true );   // Enable debug mode
define( 'WP_DEBUG_LOG',     true );   // Log to wp-content/debug.log
define( 'WP_DEBUG_DISPLAY', false );  // Never display errors to browser in any env
define( 'SCRIPT_DEBUG',     true );   // Load unminified JS/CSS
define( 'SAVEQUERIES',      true );   // Log all database queries (performance cost)

// Move debug.log outside web root for security
define( 'WP_DEBUG_LOG', '/var/log/wordpress/debug.log' );

// Script debugging
define( 'CONCATENATE_SCRIPTS', false ); // Load scripts individually (easier to debug)
```

**Query Monitor plugin:** Install in development only. Shows all database queries,
hooks fired, HTTP requests, PHP errors, and template file loaded. Remove or
deactivate before deploying to production — it exposes internal data.
