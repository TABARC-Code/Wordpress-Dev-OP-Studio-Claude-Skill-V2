# Front-End Development Reference

Author: TABARC-Code / Blackwood Studio
Load this for responsive CSS, HTML5 patterns, front-end build tooling, SCSS,
JavaScript (ES6+), and third-party plugin front-end integration (ACF, Gravity Forms).

---

## HTML5 — WordPress Context

```php
<?php
// DOCTYPE and language attribute — output by wp_head()
// In header.php:
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>  <!-- All scripts/styles registered via enqueue go here -->
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>  <!-- Required hook for cookie notices, skip links etc -->

<a class="skip-link screen-reader-text" href="#main">
    <?php esc_html_e( 'Skip to content', 'my-theme' ); ?>
</a>

<header id="masthead" role="banner">
    <nav id="site-navigation" aria-label="<?php esc_attr_e( 'Primary', 'my-theme' ); ?>">
        <?php wp_nav_menu( [ 'theme_location' => 'primary' ] ); ?>
    </nav>
</header>

<main id="main" role="main">
    <?php // Template content ?>
</main>

<footer role="contentinfo">
</footer>

<?php wp_footer(); ?>  <!-- Scripts registered with in_footer=true go here -->
</body>
</html>
```

---

## Responsive CSS — Mobile First

Write CSS mobile-first. Add breakpoints upward, not downward.

```css
/* Wrong — desktop-first, overriding with max-width */
.card {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
}
@media ( max-width: 768px ) {
    .card { display: block; }
}

/* Correct — mobile-first, enhancing with min-width */
.card {
    display: block;          /* Default: single column on mobile */
}
@media ( min-width: 48em ) {  /* 768px — tablet */
    .card {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
}
@media ( min-width: 75em ) {  /* 1200px — desktop */
    .card {
        grid-template-columns: repeat(3, 1fr);
    }
}
```

---

## CSS Custom Properties — Integration with theme.json

WordPress FSE themes expose theme.json values as CSS custom properties.

```css
/* These are automatically generated from theme.json colour palette */
--wp--preset--color--primary
--wp--preset--color--secondary
--wp--preset--spacing--20
--wp--preset--font-size--large

/* Use them in block styles and theme CSS */
.my-block {
    color: var( --wp--preset--color--primary );
    font-size: var( --wp--preset--font-size--medium );
    padding: var( --wp--preset--spacing--30 );
}

/* For classic themes — define your own custom properties */
:root {
    --color-primary:   #1a1a2e;
    --color-secondary: #e94560;
    --font-body:       'IBM Plex Mono', monospace;
    --spacing-base:    1rem;
    --radius-base:     4px;
    --container-max:   1200px;
    --container-wide:  1440px;
}
```

---

## SCSS — WordPress Theme Setup

```scss
// Style organisation for a WordPress theme
// style.scss (or src/scss/main.scss)

// 1. Variables and tokens
@import 'tokens/colours';
@import 'tokens/typography';
@import 'tokens/spacing';

// 2. Functions and mixins
@import 'mixins/breakpoints';
@import 'mixins/typography';

// 3. Base styles
@import 'base/reset';
@import 'base/typography';
@import 'base/forms';

// 4. Layout
@import 'layout/header';
@import 'layout/footer';
@import 'layout/grid';

// 5. Components
@import 'components/cards';
@import 'components/buttons';
@import 'components/navigation';

// 6. WordPress-specific
@import 'wordpress/admin-bar';
@import 'wordpress/blocks';
@import 'wordpress/alignments';
```

```scss
// _breakpoints.scss
$breakpoints: (
    'sm':  48em,    // 768px
    'md':  62em,    // 992px
    'lg':  75em,    // 1200px
    'xl':  90em,    // 1440px
);

@mixin above( $breakpoint ) {
    @media ( min-width: map-get( $breakpoints, $breakpoint ) ) {
        @content;
    }
}

// Usage
.nav {
    display: none;
    @include above( 'sm' ) {
        display: flex;
    }
}
```

---

## JavaScript ES6+ — WordPress Patterns

```javascript
// WordPress provides jQuery — but use vanilla JS for new code
// jQuery is available as wp.jQuery or window.jQuery — not loaded by default

// DOMContentLoaded equivalent in WordPress context
document.addEventListener( 'DOMContentLoaded', () => {
    initMyFeature();
} );

// Or use the load event if you need images/assets loaded
window.addEventListener( 'load', () => {
    initHeavyFeature();
} );

// Accessing localised script data (passed from wp_localize_script)
const { ajaxUrl, nonce, strings } = window.myPluginData ?? {};

// Fetch API — preferred over jQuery AJAX for new code
async function fetchData( endpoint ) {
    try {
        const response = await fetch( `${ ajaxUrl }?action=${ endpoint }`, {
            method:  'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-WP-Nonce':   nonce,
            },
            body: new URLSearchParams( { nonce } ),
        } );

        if ( ! response.ok ) {
            throw new Error( `HTTP ${ response.status }` );
        }

        return await response.json();
    } catch ( error ) {
        console.error( 'Request failed:', error );
        return null;
    }
}

// WordPress REST API fetch
async function getPost( id ) {
    const response = await fetch( `/wp-json/wp/v2/posts/${ id }`, {
        headers: { 'X-WP-Nonce': wpApiSettings.nonce },
    } );
    return response.json();
}
```

---

## ACF (Advanced Custom Fields) — Integration

ACF 6.x with `show_in_rest: true` exposes fields to the REST API and Gutenberg.

### Basic Field Access

```php
<?php
// Single field
$value = get_field( 'field_name', $post_id );
// With fallback
$value = get_field( 'field_name' ) ?: __( 'Default text', 'my-theme' );

// Always escape output — get_field() does not escape
echo esc_html( get_field( 'text_field' ) );
echo esc_url( get_field( 'url_field' ) );
echo wp_kses_post( get_field( 'wysiwyg_field' ) );

// Image field (returns array by default)
$image = get_field( 'hero_image' );
if ( $image ) {
    echo wp_get_attachment_image( $image['ID'], 'full', false, [
        'alt' => esc_attr( $image['alt'] ?: get_the_title() ),
    ] );
}

// Relationship field (returns array of WP_Post objects)
$related = get_field( 'related_posts' );
if ( $related ) {
    foreach ( $related as $post ) {
        setup_postdata( $post );
        the_title( '<h3>', '</h3>' );
        wp_reset_postdata();
    }
}
```

### Repeater and Flexible Content

```php
<?php
// Repeater field
if ( have_rows( 'team_members' ) ) {
    while ( have_rows( 'team_members' ) ) {
        the_row();
        $name = get_sub_field( 'name' );
        $role = get_sub_field( 'role' );
        echo '<p>' . esc_html( $name ) . ' — ' . esc_html( $role ) . '</p>';
    }
}

// Flexible content field
if ( have_rows( 'flexible_content' ) ) {
    while ( have_rows( 'flexible_content' ) ) {
        the_row();

        if ( is_row_layout( 'text_block' ) ) {
            $content = get_sub_field( 'content' );
            echo wp_kses_post( $content );

        } elseif ( is_row_layout( 'image_block' ) ) {
            $image = get_sub_field( 'image' );
            if ( $image ) {
                echo wp_get_attachment_image( $image['ID'], 'large' );
            }
        }
    }
}
```

### ACF Block Registration (ACF 5.8+)

```php
<?php
add_action( 'acf/init', 'my_theme_register_acf_blocks' );
function my_theme_register_acf_blocks(): void {
    acf_register_block_type(
        [
            'name'            => 'my-hero',
            'title'           => __( 'Hero Block', 'my-theme' ),
            'description'     => __( 'Full-width hero with heading and CTA.', 'my-theme' ),
            'render_template' => get_template_directory() . '/template-parts/blocks/hero.php',
            'category'        => 'layout',
            'icon'            => 'cover-image',
            'keywords'        => [ 'hero', 'banner', 'header' ],
            'supports'        => [
                'align'  => [ 'full', 'wide' ],
                'anchor' => true,
            ],
        ]
    );
}
```

---

## Gravity Forms — Common Integration Patterns

```php
<?php
// Display a form programmatically
echo gravity_form( $form_id, $display_title, $display_description, $display_inactive,
    $field_values, $ajax, $tab_index, $echo = false );

// Process submission — hook fires after successful submission
add_action( 'gform_after_submission', 'my_plugin_after_gf_submission', 10, 2 );
function my_plugin_after_gf_submission( array $entry, array $form ): void {
    if ( 3 !== (int) $form['id'] ) {
        return; // Only process form ID 3
    }
    $name  = rgar( $entry, '1' );  // Field ID 1
    $email = rgar( $entry, '2' );  // Field ID 2
    // Process entry data
}

// Populate field dynamically
add_filter( 'gform_field_value_my_param', 'my_plugin_gf_populate_field' );
function my_plugin_gf_populate_field( string $value ): string {
    return get_current_user_id() ? wp_get_current_user()->display_name : '';
}

// Never access $_POST directly for Gravity Forms data — use the entry object
// Entry data is already sanitised by Gravity Forms on submission
```

---

## WordPress Image Sizes

```php
<?php
// Register custom sizes in functions.php
add_image_size( 'hero',    1920, 600, true );   // Hard crop
add_image_size( 'card',    640,  480, true );
add_image_size( 'thumb',   300,  300, false );  // Proportional

// Output with correct size
echo get_the_post_thumbnail( $post_id, 'card', [
    'alt'     => esc_attr( get_the_title( $post_id ) ),
    'loading' => 'lazy',   // Always lazy load below-fold images
    'sizes'   => '(max-width: 640px) 100vw, 640px',
] );

// Responsive image with srcset (automatic in WordPress 4.4+)
echo wp_get_attachment_image( $attachment_id, 'large', false, [
    'alt'     => esc_attr( $alt ),
    'loading' => 'lazy',
] );
// WordPress automatically adds srcset and sizes attributes
```

---

## WP-CLI Asset Commands

```bash
# Regenerate all image thumbnails after adding new sizes
wp media regenerate --yes

# Regenerate specific attachment
wp media regenerate 42

# Import media from URL
wp media import https://example.com/image.jpg --title="Image Title"
```
