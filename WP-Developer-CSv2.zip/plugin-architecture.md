# Plugin Architecture Reference

Load this when building or auditing a plugin from scratch.

---

## Enterprise File Structure

```
my-plugin/
├── my-plugin.php              # Main plugin file (header, bootstrap only)
├── uninstall.php              # Cleanup on deletion (not deactivation)
├── readme.txt                 # WordPress.org readme format
├── composer.json              # Dependency management (see Autoloading note below)
├── includes/
│   ├── class-my-plugin.php    # Main plugin class (loader)
│   ├── class-activator.php    # Activation hooks
│   ├── class-deactivator.php  # Deactivation hooks
│   ├── admin/
│   │   ├── class-admin.php
│   │   └── partials/
│   │       └── admin-display.php
│   └── public/
│       ├── class-public.php
│       └── partials/
│           └── public-display.php
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
└── languages/
    └── my-plugin.pot
```

---

## Autoloading Note

If using `composer.json`, add PSR-4 autoloading and call the autoloader in
the main plugin file. WordPress has no built-in autoloader.

```json
{
    "autoload": {
        "psr-4": {
            "MyPlugin\\": "includes/"
        }
    }
}
```

```php
// In main plugin file, before class instantiation:
if ( file_exists( MY_PLUGIN_PATH . 'vendor/autoload.php' ) ) {
    require_once MY_PLUGIN_PATH . 'vendor/autoload.php';
}
```

If not using Composer, require class files manually in the loader class constructor.
Do not use `__autoload()` — it is deprecated in PHP 7.2 and removed in PHP 8.0.

---

## Main Plugin File

```php
<?php
/**
 * Plugin Name:       My Plugin
 * Plugin URI:        https://example.com/my-plugin
 * Description:       Brief description. No markup allowed.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Author Name
 * Author URI:        https://example.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       my-plugin
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'MY_PLUGIN_VERSION', '1.0.0' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'MY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once MY_PLUGIN_PATH . 'includes/class-my-plugin.php';

/**
 * Begins plugin execution.
 *
 * Hooked to plugins_loaded to ensure all plugins are available before
 * this plugin initialises. Guard prevents double instantiation if the
 * main file is ever required more than once.
 */
function run_my_plugin(): void {
    static $instance = null;
    if ( null !== $instance ) {
        return;
    }
    $instance = new My_Plugin();
    $instance->run();
}
add_action( 'plugins_loaded', 'run_my_plugin' );
```

---

## Hook Registration Pattern

Always use a loader class. Never register hooks in the main file.

The loader pattern below uses `object` type hint for `$component`. This requires
class instances. For static methods, pass the class name as a string. For closures,
register directly with `add_action`/`add_filter` (but note: closures cannot be
removed with `remove_action`/`remove_filter` — this is a design trade-off).

```php
<?php
class My_Plugin_Loader {
    protected array $actions = [];
    protected array $filters = [];

    public function add_action( string $hook, object $component, string $callback, int $priority = 10, int $accepted_args = 1 ): void {
        $this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
    }

    public function add_filter( string $hook, object $component, string $callback, int $priority = 10, int $accepted_args = 1 ): void {
        $this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
    }

    private function add( array $hooks, string $hook, object $component, string $callback, int $priority, int $accepted_args ): array {
        $hooks[] = [
            'hook'          => $hook,
            'component'     => $component,
            'callback'      => $callback,
            'priority'      => $priority,
            'accepted_args' => $accepted_args,
        ];
        return $hooks;
    }

    public function run(): void {
        foreach ( $this->filters as $hook ) {
            add_filter( $hook['hook'], [ $hook['component'], $hook['callback'] ], $hook['priority'], $hook['accepted_args'] );
        }
        foreach ( $this->actions as $hook ) {
            add_action( $hook['hook'], [ $hook['component'], $hook['callback'] ], $hook['priority'], $hook['accepted_args'] );
        }
    }
}
```

---

## Activation and Deactivation

```php
<?php
class My_Plugin_Activator {
    public static function activate(): void {
        // Register CPTs here so they exist before flushing rewrite rules.
        // Do not rely on the init hook — it will not have fired yet at activation.
        my_plugin_register_post_type();

        // Create custom tables.
        self::create_tables();

        // Flush rewrite rules after registering CPTs.
        // Only flush on activation — never on init or every page load.
        flush_rewrite_rules();
    }

    private static function create_tables(): void {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name      = $wpdb->prefix . 'my_plugin_data';

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            data longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }
}

class My_Plugin_Deactivator {
    public static function deactivate(): void {
        // Flush rewrite rules — removes CPT rewrite slugs.
        flush_rewrite_rules();

        // Clear all plugin-registered scheduled events.
        wp_clear_scheduled_hook( 'my_plugin_hourly_event' );

        // Clear plugin transients.
        delete_transient( 'my_plugin_expensive_data' );

        // Do NOT delete plugin data or options on deactivation.
        // That belongs in uninstall.php only.
    }
}

// Register hooks in main plugin file:
// register_activation_hook( __FILE__, [ 'My_Plugin_Activator', 'activate' ] );
// register_deactivation_hook( __FILE__, [ 'My_Plugin_Deactivator', 'deactivate' ] );
```

---

## Settings API Pattern

```php
<?php
class My_Plugin_Settings {
    public function register_settings(): void {
        register_setting(
            'my_plugin_options',
            'my_plugin_settings',
            [
                'sanitize_callback' => [ $this, 'sanitize_settings' ],
                'default'           => [],
            ]
        );

        add_settings_section(
            'my_plugin_main',
            __( 'Main Settings', 'my-plugin' ),
            [ $this, 'section_callback' ],
            'my-plugin'
        );

        add_settings_field(
            'my_plugin_api_key',
            __( 'API Key', 'my-plugin' ),
            [ $this, 'api_key_field_callback' ],
            'my-plugin',
            'my_plugin_main'
        );
    }

    public function section_callback(): void {
        echo '<p>' . esc_html__( 'Configure the main plugin settings below.', 'my-plugin' ) . '</p>';
    }

    public function api_key_field_callback(): void {
        $options = get_option( 'my_plugin_settings', [] );
        $value   = $options['api_key'] ?? '';
        ?>
        <input
            type="text"
            id="my_plugin_api_key"
            name="my_plugin_settings[api_key]"
            value="<?php echo esc_attr( $value ); ?>"
            class="regular-text"
        />
        <p class="description"><?php esc_html_e( 'Enter your API key.', 'my-plugin' ); ?></p>
        <?php
    }

    public function sanitize_settings( mixed $input ): array {
        $sanitized = [];

        if ( isset( $input['api_key'] ) ) {
            $sanitized['api_key'] = sanitize_text_field( wp_unslash( $input['api_key'] ) );
        }

        return $sanitized;
    }
}
```

---

## Custom Post Type Registration

Register CPTs inside a class method and wire through the loader. The global function
pattern shown below is for standalone context; production code uses the loader class.

```php
<?php
// In a class (preferred — use loader pattern):
class My_Plugin_Post_Types {
    public function register(): void {
        $this->register_item_post_type();
    }

    private function register_item_post_type(): void {
        $labels = [
            'name'          => _x( 'Items', 'post type general name', 'my-plugin' ),
            'singular_name' => _x( 'Item', 'post type singular name', 'my-plugin' ),
            'add_new_item'  => __( 'Add New Item', 'my-plugin' ),
            'edit_item'     => __( 'Edit Item', 'my-plugin' ),
            'view_item'     => __( 'View Item', 'my-plugin' ),
            'not_found'     => __( 'No items found.', 'my-plugin' ),
        ];

        register_post_type(
            'my_item',
            [
                'labels'       => $labels,
                'public'       => true,
                'has_archive'  => true,
                'rewrite'      => [ 'slug' => 'items' ],
                'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
                'show_in_rest' => true,
                'menu_icon'    => 'dashicons-portfolio',
            ]
        );
    }
}

// In loader bootstrap:
// $post_types = new My_Plugin_Post_Types();
// $loader->add_action( 'init', $post_types, 'register' );

// Standalone function (used only in Activator for pre-init flush timing):
// Call directly from Activator::activate() before flush_rewrite_rules().
function my_plugin_register_post_type(): void {
    $labels = [
        'name'          => _x( 'Items', 'post type general name', 'my-plugin' ),
        'singular_name' => _x( 'Item', 'post type singular name', 'my-plugin' ),
        'add_new_item'  => __( 'Add New Item', 'my-plugin' ),
        'edit_item'     => __( 'Edit Item', 'my-plugin' ),
        'view_item'     => __( 'View Item', 'my-plugin' ),
        'not_found'     => __( 'No items found.', 'my-plugin' ),
    ];

    register_post_type(
        'my_item',
        [
            'labels'       => $labels,
            'public'       => true,
            'has_archive'  => true,
            'rewrite'      => [ 'slug' => 'items' ],
            'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
            'show_in_rest' => true,
            'menu_icon'    => 'dashicons-portfolio',
        ]
    );
}
```

---

## Enqueue Pattern

```php
<?php
class My_Plugin_Public {
    public function enqueue_scripts(): void {
        // Only enqueue on relevant pages
        if ( ! is_singular( 'my_item' ) ) {
            return;
        }

        wp_enqueue_style(
            'my-plugin-public',
            MY_PLUGIN_URL . 'assets/css/public.css',
            [],
            MY_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'my-plugin-public',
            MY_PLUGIN_URL . 'assets/js/public.js',
            [ 'jquery' ],
            MY_PLUGIN_VERSION,
            true  // Load in footer
        );

        wp_localize_script(
            'my-plugin-public',
            'myPluginData',
            [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'my_plugin_nonce' ),
            ]
        );
    }
}
```

---

## Database Schema — Version-Controlled Upgrades

`dbDelta()` only runs on activation. For schema changes after a plugin is installed,
you need an upgrade routine that fires on plugin update.

```php
<?php
/**
 * Runs database upgrade routines when the plugin version changes.
 * Hook this to 'plugins_loaded' — fires on every page load, but the version
 * check keeps it cheap.
 */
function my_plugin_maybe_upgrade(): void {
    $installed_version = get_option( 'my_plugin_db_version', '0.0.0' );

    if ( version_compare( $installed_version, MY_PLUGIN_VERSION, '<' ) ) {
        my_plugin_run_upgrades( $installed_version );
        update_option( 'my_plugin_db_version', MY_PLUGIN_VERSION );
    }
}
add_action( 'plugins_loaded', 'my_plugin_maybe_upgrade' );

/**
 * Runs sequential upgrade routines in version order.
 *
 * @param string $installed_version The version currently recorded in wp_options.
 */
function my_plugin_run_upgrades( string $installed_version ): void {
    // Each block runs only once — when upgrading from below that version.

    if ( version_compare( $installed_version, '1.1.0', '<' ) ) {
        my_plugin_upgrade_to_1_1_0();
    }

    if ( version_compare( $installed_version, '1.2.0', '<' ) ) {
        my_plugin_upgrade_to_1_2_0();
    }
}

/**
 * Upgrade routine for 1.1.0: adds status column to the items table.
 */
function my_plugin_upgrade_to_1_1_0(): void {
    global $wpdb;

    $table = $wpdb->prefix . 'my_plugin_data';

    // Check if column already exists before adding — dbDelta handles CREATE TABLE
    // idempotently, but ALTER TABLE does not. Guard manually.
    $column_exists = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            DB_NAME,
            $table,
            'status'
        )
    );

    if ( empty( $column_exists ) ) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "ALTER TABLE {$table} ADD COLUMN status varchar(20) NOT NULL DEFAULT 'active'" );
    }
}

/**
 * Upgrade routine for 1.2.0: creates a new related table.
 */
function my_plugin_upgrade_to_1_2_0(): void {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE {$wpdb->prefix}my_plugin_meta (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        item_id bigint(20) UNSIGNED NOT NULL,
        meta_key varchar(255) NOT NULL,
        meta_value longtext,
        PRIMARY KEY (id),
        KEY item_id (item_id),
        KEY meta_key (meta_key(191))
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}
```

**Rules for upgrade routines:**
- Always check current installed version against `MY_PLUGIN_VERSION` before running
- Run routines sequentially in version order — never skip
- Guard `ALTER TABLE` with a column-existence check — `dbDelta()` handles `CREATE TABLE`
  idempotently but not `ALTER TABLE`
- Store the installed version in `wp_options` — never hardcode it
- On plugin activation, set `my_plugin_db_version` to `MY_PLUGIN_VERSION` so the
  upgrade routine does not fire on fresh installs
